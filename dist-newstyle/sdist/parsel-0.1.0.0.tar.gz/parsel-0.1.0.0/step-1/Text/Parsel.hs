module Text.Parsel (
  module Text.Parsel.Primitives
) where

import Text.Parsel.Primitives