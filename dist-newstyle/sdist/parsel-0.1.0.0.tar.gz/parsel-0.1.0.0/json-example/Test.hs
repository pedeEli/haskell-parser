module Test (
  module Text.Parsel
) where

import Text.Parsel
import Control.Applicative